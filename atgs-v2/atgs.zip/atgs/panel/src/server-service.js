const fs = require('fs');
const path = require('path');
const config = require('./config');
const db = require('./db');
const agent = require('./agent');
const modrinth = require('./modrinth');
const { serializeProperties } = require('./properties');

const addonCatalog = {
  geyser: { slug: 'geyser', label: 'Geyser' },
  floodgate: { slug: 'floodgate', label: 'Floodgate' }
};

async function ensureProperties(server) {
  let existing = '';
  try {
    existing = (await agent.readFile('server.properties')).content || '';
  } catch {}

  const content = serializeProperties(existing, {
    'server-port': '25565',
    'motd': server.motd,
    'online-mode': server.onlineMode ? 'true' : 'false',
    'max-players': String(server.maxPlayers),
    'difficulty': server.difficulty,
    'view-distance': String(server.viewDistance),
    'simulation-distance': String(server.simulationDistance),
    'white-list': server.whitelistEnabled ? 'true' : 'false',
    'level-name': server.levelName,
    'enable-rcon': config.rconEnabled ? 'true' : 'false',
    'rcon.port': String(server.rconPort),
    'rcon.password': server.rconPassword
  });

  await agent.writeFile('server.properties', content);
}

async function getRuntime(server) {
  const [status, stats] = await Promise.all([
    agent.runtimeStatus().catch(() => ({ exists: false, running: false, status: 'missing', health: 'unknown' })),
    agent.runtimeStats().catch(() => null)
  ]);

  const runtime = { ...status, stats };

  if (!runtime.running && ['running', 'idle', 'waking', 'stopping'].includes(server.state)) {
    server = db.saveServer({ state: 'sleeping' });
  } else if (runtime.running && server.state === 'waking' && runtime.health === 'healthy') {
    server = db.saveServer({ state: 'running' });
  }

  return { server, runtime };
}

async function getServerSummary() {
  let server = db.getServer();
  const hydrated = await getRuntime(server);
  server = hydrated.server;
  const runtime = hydrated.runtime;

  let players = { online: false, players: 0, maxPlayers: server.maxPlayers, playerNames: [] };
  let tps = 'N/A';
  if (config.rconEnabled && runtime.running && runtime.health !== 'unhealthy') {
    const telemetry = await agent.runtimeTelemetry(server).catch(() => null);
    if (telemetry) {
      players = telemetry.players || players;
      tps = telemetry.tps || tps;
    }
  }

  return {
    ...server,
    runtime,
    players,
    tps,
    ready: Boolean(runtime.running && runtime.health === 'healthy'),
    security: {
      adminDirectExposureDisabled: !config.panelDirectPublish,
      authProxyActive: config.authProxyEnabled,
      ipAllowlistActive: config.adminAllowedCidrs.length > 0,
      ipAllowlistRules: config.adminAllowedCidrs,
      socketProxyActive: config.socketProxyEnabled,
      agentInternalOnly: true,
      bedrockPublished: Boolean(server.geyserEnabled),
      rconInternalOnly: config.rconEnabled,
      adminDomain: config.adminDomain,
      authDomain: config.authDomain
    }
  };
}

async function reconcileRuntime() {
  const server = db.getServer();
  await ensureProperties(server);
  return agent.reconcileRuntime(server);
}

async function bootstrapServer({ flavor, version }) {
  const updated = db.saveServer({
    flavor: flavor || db.getServer().flavor,
    version: version || db.getServer().version,
    state: 'provisioning'
  });
  await agent.bootstrapRuntime(updated);
  await ensureProperties(updated);
  db.saveServer({ state: 'sleeping' });
  return getServerSummary();
}

async function waitForReady(timeoutMs = config.wakeTimeoutMs) {
  const startedAt = Date.now();
  while (Date.now() - startedAt < timeoutMs) {
    const summary = await getServerSummary();
    if (summary.ready) return summary;
    await new Promise((resolve) => setTimeout(resolve, config.wakePollMs));
  }
  return getServerSummary();
}

async function wakeServer(reason = 'manual') {
  await reconcileRuntime();
  db.saveServer({ state: 'waking' });
  await agent.startRuntime();
  const summary = await waitForReady();
  if (summary.ready) db.saveServer({ state: 'running', lastEmptyAt: null });
  return { ...(await getServerSummary()), wakeReason: reason };
}

async function sleepServer(reason = 'manual') {
  try {
    await sendConsoleCommand('save-all flush');
  } catch {}
  db.saveServer({ state: 'stopping' });
  await agent.stopRuntime(reason);
  db.saveServer({ state: 'sleeping', lastEmptyAt: null });
  return getServerSummary();
}

async function restartServer() {
  db.saveServer({ state: 'waking' });
  await agent.restartRuntime();
  const summary = await waitForReady();
  if (summary.ready) db.saveServer({ state: 'running' });
  return getServerSummary();
}

async function updateServerSettings(patch) {
  const current = db.getServer();
  const next = db.saveServer({ ...current, ...patch });
  await ensureProperties(next);
  await reconcileRuntime();
  return getServerSummary();
}

async function createBackup(label) {
  return agent.createBackup(db.getServer(), listAddons(), label || 'manual');
}

async function restoreBackup(name) {
  const server = db.saveServer({ state: 'restoring' });
  const result = await agent.restoreBackup(server, name);
  if (result?.serverConfig) {
    db.saveServer({
      ...result.serverConfig,
      state: 'sleeping',
      lastEmptyAt: null
    });
  }
  await ensureProperties(db.getServer());
  db.saveServer({ state: 'sleeping' });
  return { ...(await getServerSummary()), restore: result || { format: 'legacy' } };
}

async function importLegacyBackup(filename) {
  const server = db.saveServer({ state: 'importing' });
  const result = await agent.importLegacyBackup(server, filename);
  if (result?.serverConfig) {
    db.saveServer({
      ...result.serverConfig,
      state: 'sleeping',
      lastEmptyAt: null
    });
  }
  await ensureProperties(db.getServer());
  db.saveServer({ state: 'sleeping' });
  return { ...(await getServerSummary()), restore: result || { format: 'legacy-files' } };
}

async function sendConsoleCommand(command) {
  if (!config.rconEnabled) {
    throw new Error('RCON-backed server commands are disabled for this deployment');
  }

  const server = db.getServer();
  const response = await agent.runtimeCommand(server, command);
  return response.response;
}

function listAddons() {
  const pluginsDir = path.join(config.serverFilesDir, 'plugins');
  if (!fs.existsSync(pluginsDir)) return [];
  return modrinth.listInstalled(config.serverFilesDir, 'plugins');
}

function installAddon(addonId) {
  const addon = addonCatalog[addonId];
  if (!addon) throw new Error('Unknown addon');
  const server = db.getServer();
  return modrinth.installModWithDeps(addon.slug, config.serverFilesDir, {
    loader: 'paper',
    gameVersion: server.version === 'latest' ? '' : server.version,
    subDir: 'plugins'
  });
}

module.exports = {
  getServerSummary,
  reconcileRuntime,
  bootstrapServer,
  wakeServer,
  sleepServer,
  restartServer,
  updateServerSettings,
  createBackup,
  restoreBackup,
  importLegacyBackup,
  sendConsoleCommand,
  listAddons,
  installAddon
};
