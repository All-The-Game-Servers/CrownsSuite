const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Database = require('better-sqlite3');
const config = require('./config');

fs.mkdirSync(path.dirname(config.dbPath), { recursive: true });

const db = new Database(config.dbPath);
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS server_config (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    state TEXT NOT NULL,
    flavor TEXT NOT NULL,
    version TEXT NOT NULL,
    profile TEXT NOT NULL,
    min_ram TEXT NOT NULL,
    max_ram TEXT NOT NULL,
    game_port INTEGER NOT NULL,
    gateway_port INTEGER NOT NULL,
    bedrock_port INTEGER NOT NULL,
    geyser_enabled INTEGER NOT NULL,
    sleep_enabled INTEGER NOT NULL,
    idle_grace_seconds INTEGER NOT NULL,
    motd TEXT NOT NULL,
    difficulty TEXT NOT NULL,
    max_players INTEGER NOT NULL,
    online_mode INTEGER NOT NULL,
    whitelist_enabled INTEGER NOT NULL,
    view_distance INTEGER NOT NULL,
    simulation_distance INTEGER NOT NULL,
    level_name TEXT NOT NULL,
    rcon_port INTEGER NOT NULL,
    rcon_password TEXT NOT NULL,
    java_args TEXT NOT NULL,
    last_empty_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
`);

function hashPass(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  return `${salt}:${crypto.scryptSync(password, salt, 64).toString('hex')}`;
}

function verifyPass(password, stored) {
  const [salt, hash] = String(stored || '').split(':');
  if (!salt || !hash) return false;
  return crypto.scryptSync(password, salt, 64).toString('hex') === hash;
}

function mapUser(row) {
  if (!row) return null;
  return {
    id: row.id,
    username: row.username,
    password: row.password,
    role: row.role,
    createdAt: row.created_at
  };
}

function mapServer(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    state: row.state,
    flavor: row.flavor,
    version: row.version,
    profile: row.profile,
    minRam: row.min_ram,
    maxRam: row.max_ram,
    gamePort: row.game_port,
    gatewayPort: row.gateway_port,
    bedrockPort: row.bedrock_port,
    geyserEnabled: Boolean(row.geyser_enabled),
    sleepEnabled: Boolean(row.sleep_enabled),
    idleGraceSeconds: row.idle_grace_seconds,
    motd: row.motd,
    difficulty: row.difficulty,
    maxPlayers: row.max_players,
    onlineMode: Boolean(row.online_mode),
    whitelistEnabled: Boolean(row.whitelist_enabled),
    viewDistance: row.view_distance,
    simulationDistance: row.simulation_distance,
    levelName: row.level_name,
    rconPort: row.rcon_port,
    rconPassword: row.rcon_password,
    javaArgs: row.java_args,
    lastEmptyAt: row.last_empty_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

const insertUser = db.prepare(`
  INSERT INTO users (id, username, password, role, created_at)
  VALUES (@id, @username, @password, @role, @created_at)
`);

const updateUser = db.prepare(`
  UPDATE users
  SET username = @username,
      password = COALESCE(@password, password),
      role = @role
  WHERE id = @id
`);

const moveUserId = db.prepare(`
  UPDATE users
  SET id = @nextId,
      username = @username,
      role = @role
  WHERE id = @currentId
`);

const upsertServer = db.prepare(`
  INSERT INTO server_config (
    id, name, state, flavor, version, profile, min_ram, max_ram, game_port,
    gateway_port, bedrock_port, geyser_enabled, sleep_enabled, idle_grace_seconds,
    motd, difficulty, max_players, online_mode, whitelist_enabled, view_distance,
    simulation_distance, level_name, rcon_port, rcon_password, java_args,
    last_empty_at, created_at, updated_at
  ) VALUES (
    @id, @name, @state, @flavor, @version, @profile, @minRam, @maxRam, @gamePort,
    @gatewayPort, @bedrockPort, @geyserEnabled, @sleepEnabled, @idleGraceSeconds,
    @motd, @difficulty, @maxPlayers, @onlineMode, @whitelistEnabled, @viewDistance,
    @simulationDistance, @levelName, @rconPort, @rconPassword, @javaArgs,
    @lastEmptyAt, @createdAt, @updatedAt
  )
  ON CONFLICT(id) DO UPDATE SET
    name=excluded.name,
    state=excluded.state,
    flavor=excluded.flavor,
    version=excluded.version,
    profile=excluded.profile,
    min_ram=excluded.min_ram,
    max_ram=excluded.max_ram,
    game_port=excluded.game_port,
    gateway_port=excluded.gateway_port,
    bedrock_port=excluded.bedrock_port,
    geyser_enabled=excluded.geyser_enabled,
    sleep_enabled=excluded.sleep_enabled,
    idle_grace_seconds=excluded.idle_grace_seconds,
    motd=excluded.motd,
    difficulty=excluded.difficulty,
    max_players=excluded.max_players,
    online_mode=excluded.online_mode,
    whitelist_enabled=excluded.whitelist_enabled,
    view_distance=excluded.view_distance,
    simulation_distance=excluded.simulation_distance,
    level_name=excluded.level_name,
    rcon_port=excluded.rcon_port,
    rcon_password=excluded.rcon_password,
    java_args=excluded.java_args,
    last_empty_at=excluded.last_empty_at,
    updated_at=excluded.updated_at
`);

function ensureDefaults() {
  const ownerById = db.prepare('SELECT * FROM users WHERE id = ?').get('owner');
  const ownerByUsername = db.prepare('SELECT * FROM users WHERE username = ?').get(config.ownerUser);

  if (!ownerById && !ownerByUsername) {
    insertUser.run({
      id: 'owner',
      username: config.ownerUser,
      password: hashPass(config.adminPass),
      role: 'owner',
      created_at: new Date().toISOString()
    });
  } else if (ownerById) {
    updateUser.run({
      id: 'owner',
      username: config.ownerUser,
      password: null,
      role: 'owner'
    });
  } else if (ownerByUsername && ownerByUsername.id !== 'owner') {
    moveUserId.run({
      currentId: ownerByUsername.id,
      nextId: 'owner',
      username: config.ownerUser,
      role: 'owner'
    });
  }

  const current = db.prepare('SELECT * FROM server_config WHERE id = ?').get(config.defaultServer.id);
  if (!current) {
    const now = new Date().toISOString();
    upsertServer.run({
      ...config.defaultServer,
      geyserEnabled: config.defaultServer.geyserEnabled ? 1 : 0,
      sleepEnabled: config.defaultServer.sleepEnabled ? 1 : 0,
      onlineMode: config.defaultServer.onlineMode ? 1 : 0,
      whitelistEnabled: config.defaultServer.whitelistEnabled ? 1 : 0,
      lastEmptyAt: null,
      createdAt: now,
      updatedAt: now
    });
  }
}

ensureDefaults();

function getUserByUsername(username) {
  return mapUser(db.prepare('SELECT * FROM users WHERE username = ?').get(username));
}

function getUserById(id) {
  return mapUser(db.prepare('SELECT * FROM users WHERE id = ?').get(id));
}

function listUsers() {
  return db.prepare('SELECT * FROM users ORDER BY created_at ASC').all().map(mapUser);
}

function createUser({ id, username, password, role }) {
  const row = {
    id,
    username,
    password,
    role,
    created_at: new Date().toISOString()
  };
  insertUser.run(row);
  return getUserById(id);
}

function resetOwnerPasswordFromSecret() {
  updateUser.run({
    id: 'owner',
    username: config.ownerUser,
    password: hashPass(config.adminPass),
    role: 'owner'
  });
  return getUserById('owner');
}

function deleteUser(id) {
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
}

function getServer() {
  return mapServer(db.prepare('SELECT * FROM server_config WHERE id = ?').get(config.defaultServer.id));
}

function saveServer(server) {
  const current = getServer();
  const now = new Date().toISOString();
  const payload = {
    ...current,
    ...server,
    geyserEnabled: server.geyserEnabled !== undefined ? (server.geyserEnabled ? 1 : 0) : (current.geyserEnabled ? 1 : 0),
    sleepEnabled: server.sleepEnabled !== undefined ? (server.sleepEnabled ? 1 : 0) : (current.sleepEnabled ? 1 : 0),
    onlineMode: server.onlineMode !== undefined ? (server.onlineMode ? 1 : 0) : (current.onlineMode ? 1 : 0),
    whitelistEnabled: server.whitelistEnabled !== undefined ? (server.whitelistEnabled ? 1 : 0) : (current.whitelistEnabled ? 1 : 0),
    createdAt: current.createdAt,
    updatedAt: now
  };
  upsertServer.run(payload);
  return getServer();
}

module.exports = {
  db,
  hashPass,
  verifyPass,
  getUserByUsername,
  getUserById,
  listUsers,
  createUser,
  deleteUser,
  resetOwnerPasswordFromSecret,
  getServer,
  saveServer
};
