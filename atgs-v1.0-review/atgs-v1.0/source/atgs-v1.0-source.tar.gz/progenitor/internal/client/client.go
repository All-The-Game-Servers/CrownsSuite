// Package client is Progenitor's Go-side ATGS API client.
//
// It loads a progenitor bundle (cert/key/ca) from disk, builds an mTLS
// http.Client, and offers typed methods for each admin endpoint. Called from
// the Wails bindings in app.go.
package client

import (
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// Bundle is the on-disk bundle issued by `central mint-progenitor-cert`.
type Bundle struct {
	ProgenitorID string
	Certificate  tls.Certificate
	CACertPool   *x509.CertPool
	CertNotAfter time.Time
}

// LoadBundle reads the four-file bundle from dir.
func LoadBundle(dir string) (*Bundle, error) {
	idBytes, err := os.ReadFile(filepath.Join(dir, "progenitor.id"))
	if err != nil {
		return nil, fmt.Errorf("read progenitor.id: %w", err)
	}
	certPEM, err := os.ReadFile(filepath.Join(dir, "client.crt"))
	if err != nil {
		return nil, fmt.Errorf("read client.crt: %w", err)
	}
	keyPEM, err := os.ReadFile(filepath.Join(dir, "client.key"))
	if err != nil {
		return nil, fmt.Errorf("read client.key: %w", err)
	}
	caPEM, err := os.ReadFile(filepath.Join(dir, "ca.crt"))
	if err != nil {
		return nil, fmt.Errorf("read ca.crt: %w", err)
	}
	cert, err := tls.X509KeyPair(certPEM, keyPEM)
	if err != nil {
		return nil, fmt.Errorf("load keypair: %w", err)
	}
	pool := x509.NewCertPool()
	if !pool.AppendCertsFromPEM(caPEM) {
		return nil, errors.New("ca.crt contains no certificates")
	}
	// Parse leaf for expiry info shown in the UI.
	if len(cert.Certificate) == 0 {
		return nil, errors.New("no leaf cert in bundle")
	}
	leaf, err := x509.ParseCertificate(cert.Certificate[0])
	if err != nil {
		return nil, fmt.Errorf("parse leaf: %w", err)
	}
	return &Bundle{
		ProgenitorID: strings.TrimSpace(string(idBytes)),
		Certificate:  cert,
		CACertPool:   pool,
		CertNotAfter: leaf.NotAfter,
	}, nil
}

// Client is an authenticated admin client.
type Client struct {
	baseURL    string
	httpClient *http.Client
	bundle     *Bundle
}

// Config is what New needs.
type Config struct {
	// CentralURL is the https://host:port root. Progenitor appends /api/v1/admin
	// to every request. Example: https://central.atgslowlightsmp.mine.bz:8443
	CentralURL string

	Bundle *Bundle

	// InsecureSkipVerify disables server cert verification. Useful only for
	// local dev where Central uses its self-issued cert. The UI surfaces this
	// as a checkbox on the connection setup screen.
	InsecureSkipVerify bool

	// Timeout is the per-request timeout. 30s default; bump for long-running
	// things like a restore trigger.
	Timeout time.Duration
}

// New builds the client. Returns an error if the config is obviously wrong
// (missing URL, missing bundle) but does NOT hit the network.
func New(cfg Config) (*Client, error) {
	if cfg.CentralURL == "" {
		return nil, errors.New("central URL required")
	}
	if cfg.Bundle == nil {
		return nil, errors.New("bundle required")
	}
	timeout := cfg.Timeout
	if timeout == 0 {
		timeout = 30 * time.Second
	}
	tlsCfg := &tls.Config{
		Certificates:       []tls.Certificate{cfg.Bundle.Certificate},
		RootCAs:            cfg.Bundle.CACertPool,
		InsecureSkipVerify: cfg.InsecureSkipVerify,
		MinVersion:         tls.VersionTLS12,
	}
	return &Client{
		baseURL:    strings.TrimRight(cfg.CentralURL, "/"),
		bundle:     cfg.Bundle,
		httpClient: &http.Client{
			Timeout:   timeout,
			Transport: &http.Transport{TLSClientConfig: tlsCfg},
		},
	}, nil
}

// Bundle returns the bundle the client was built from. Useful for the UI to
// display identity info.
func (c *Client) Bundle() *Bundle { return c.bundle }

// do is the shared request flow. method is "GET"/"POST"/etc; path is the
// sub-path under /api/v1/admin (e.g. "whoami", "keepers").
// body is optional; if non-nil it's marshalled to JSON.
// into is optional; if non-nil the response body is unmarshalled into it.
func (c *Client) do(ctx context.Context, method, path string, body, into any) error {
	url := c.baseURL + "/api/v1/admin/" + strings.TrimLeft(path, "/")

	var bodyReader io.Reader
	if body != nil {
		bodyJSON, err := json.Marshal(body)
		if err != nil {
			return fmt.Errorf("marshal request: %w", err)
		}
		bodyReader = bytes.NewReader(bodyJSON)
	}

	req, err := http.NewRequestWithContext(ctx, method, url, bodyReader)
	if err != nil {
		return err
	}
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	resp, err := c.httpClient.Do(req)
	if err != nil {
		return fmt.Errorf("%s %s: %w", method, url, err)
	}
	defer resp.Body.Close()
	respBytes, _ := io.ReadAll(resp.Body)

	if resp.StatusCode >= 400 {
		// Try to unmarshal the error envelope Central returns.
		var errEnv struct {
			Error   string `json:"error"`
			Message string `json:"message"`
		}
		_ = json.Unmarshal(respBytes, &errEnv)
		if errEnv.Error != "" {
			return &APIError{
				Status:  resp.StatusCode,
				Code:    errEnv.Error,
				Message: errEnv.Message,
			}
		}
		return &APIError{
			Status:  resp.StatusCode,
			Message: string(respBytes),
		}
	}
	if into == nil || len(respBytes) == 0 {
		return nil
	}
	if err := json.Unmarshal(respBytes, into); err != nil {
		return fmt.Errorf("decode response: %w", err)
	}
	return nil
}

// APIError is what client calls return on non-2xx responses. The UI checks the
// Status field to distinguish auth failures (403) from missing resources (404)
// from server errors (5xx).
type APIError struct {
	Status  int    `json:"status"`
	Code    string `json:"code,omitempty"`
	Message string `json:"message,omitempty"`
}

func (e *APIError) Error() string {
	if e.Code != "" {
		return fmt.Sprintf("api: %d %s: %s", e.Status, e.Code, e.Message)
	}
	return fmt.Sprintf("api: %d: %s", e.Status, e.Message)
}

// ---- Typed response shapes (mirrors what Central returns) ----

type WhoamiResponse struct {
	ProgenitorID  string    `json:"progenitor_id"`
	OU            []string  `json:"ou"`
	CertNotAfter  time.Time `json:"cert_not_after"`
	ServerVersion string    `json:"server_version"`
}

type Keeper struct {
	ID          string     `json:"id"`
	Version     string     `json:"version"`
	State       string     `json:"state"`
	CertNotAfter time.Time `json:"cert_not_after"`
	CreatedAt   time.Time  `json:"created_at"`
	LastSeenAt  *time.Time `json:"last_seen_at,omitempty"`
}

type KeeperList struct {
	Keepers []Keeper `json:"keepers"`
}

type Instance struct {
	InstanceID  string    `json:"instance_id"`
	KeeperID    string    `json:"keeper_id"`
	EggID       string    `json:"egg_id"`
	DisplayName string    `json:"display_name"`
	State       string    `json:"state"`
	MemoryBytes int64     `json:"memory_bytes"`
	CPUShares   int64     `json:"cpu_shares"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

type InstanceList struct {
	Instances []Instance `json:"instances"`
}

type Backup struct {
	BackupID    string     `json:"backup_id"`
	InstanceID  string     `json:"instance_id"`
	DisplayName string     `json:"display_name"`
	Status      string     `json:"status"`
	StorageMode string     `json:"storage_mode"`
	TotalBytes  int64      `json:"total_bytes"`
	ChunkCount  int        `json:"chunk_count"`
	Encrypted   bool       `json:"encrypted"`
	CreatedAt   time.Time  `json:"created_at"`
	CompletedAt *time.Time `json:"completed_at,omitempty"`
	Error       string     `json:"error,omitempty"`
}

type BackupList struct {
	Backups []Backup `json:"backups"`
}

type Schedule struct {
	ScheduleID   string     `json:"schedule_id"`
	InstanceID   string     `json:"instance_id"`
	CronExpr     string     `json:"cron_expr"`
	Enabled      bool       `json:"enabled"`
	Retention    int        `json:"retention"`
	Encrypt      bool       `json:"encrypt"`
	NextRunAt    time.Time  `json:"next_run_at"`
	LastRunAt    *time.Time `json:"last_run_at,omitempty"`
	LastBackupID *string    `json:"last_backup_id,omitempty"`
}

type ScheduleList struct {
	Schedules []Schedule `json:"schedules"`
}

// ---- Typed endpoint methods ----

func (c *Client) Whoami(ctx context.Context) (*WhoamiResponse, error) {
	var out WhoamiResponse
	if err := c.do(ctx, "GET", "whoami", nil, &out); err != nil {
		return nil, err
	}
	return &out, nil
}

func (c *Client) ListKeepers(ctx context.Context) ([]Keeper, error) {
	var out KeeperList
	if err := c.do(ctx, "GET", "keepers", nil, &out); err != nil {
		return nil, err
	}
	return out.Keepers, nil
}

func (c *Client) ListAllInstances(ctx context.Context) ([]Instance, error) {
	var out InstanceList
	if err := c.do(ctx, "GET", "instances", nil, &out); err != nil {
		return nil, err
	}
	return out.Instances, nil
}

func (c *Client) ListInstancesForKeeper(ctx context.Context, keeperID string) ([]Instance, error) {
	var out InstanceList
	if err := c.do(ctx, "GET", "keepers/"+keeperID+"/instances", nil, &out); err != nil {
		return nil, err
	}
	return out.Instances, nil
}

type CreateInstanceRequest struct {
	EggID       string            `json:"egg_id"`
	DisplayName string            `json:"display_name"`
	Hostname    string            `json:"hostname,omitempty"`
	Env         map[string]string `json:"env,omitempty"`
	MemoryBytes int64             `json:"memory_bytes"`
	CPUShares   int64             `json:"cpu_shares"`
}

type CreateInstanceResponse struct {
	InstanceID string `json:"instance_id"`
	TaskID     string `json:"task_id"`
	Hostname   string `json:"hostname,omitempty"`
}

func (c *Client) CreateInstance(ctx context.Context, keeperID string, req CreateInstanceRequest) (*CreateInstanceResponse, error) {
	var out CreateInstanceResponse
	if err := c.do(ctx, "POST", "keepers/"+keeperID+"/instances", req, &out); err != nil {
		return nil, err
	}
	return &out, nil
}

func (c *Client) StartInstance(ctx context.Context, instanceID string) error {
	return c.do(ctx, "POST", "instances/"+instanceID+"/start", nil, nil)
}

func (c *Client) StopInstance(ctx context.Context, instanceID string) error {
	return c.do(ctx, "POST", "instances/"+instanceID+"/stop", nil, nil)
}

func (c *Client) DeleteInstance(ctx context.Context, instanceID string) error {
	return c.do(ctx, "DELETE", "instances/"+instanceID, nil, nil)
}

type CreateBackupRequest struct {
	DisplayName      string `json:"display_name,omitempty"`
	StorageMode      string `json:"storage_mode,omitempty"`
	Encrypted        bool   `json:"encrypted,omitempty"`
	StopDuringBackup bool   `json:"stop_during_backup,omitempty"`
}

type CreateBackupResponse struct {
	BackupID    string `json:"backup_id"`
	TaskID      string `json:"task_id"`
	InstanceID  string `json:"instance_id"`
	StorageMode string `json:"storage_mode"`
	Encrypted   bool   `json:"encrypted"`
}

func (c *Client) CreateBackup(ctx context.Context, instanceID string, req CreateBackupRequest) (*CreateBackupResponse, error) {
	var out CreateBackupResponse
	if err := c.do(ctx, "POST", "instances/"+instanceID+"/backups", req, &out); err != nil {
		return nil, err
	}
	return &out, nil
}

func (c *Client) ListBackupsForInstance(ctx context.Context, instanceID string) ([]Backup, error) {
	var out BackupList
	if err := c.do(ctx, "GET", "instances/"+instanceID+"/backups", nil, &out); err != nil {
		return nil, err
	}
	return out.Backups, nil
}

func (c *Client) DeleteBackup(ctx context.Context, backupID string) error {
	return c.do(ctx, "DELETE", "backups/"+backupID, nil, nil)
}

type RestoreBackupRequest struct {
	TargetInstanceID string `json:"target_instance_id"`
}

func (c *Client) RestoreBackup(ctx context.Context, backupID string, req RestoreBackupRequest) error {
	return c.do(ctx, "POST", "backups/"+backupID+"/restore", req, nil)
}

type CreateScheduleRequest struct {
	CronExpr    string `json:"cron_expr"`
	Retention   int    `json:"retention,omitempty"`
	StorageMode string `json:"storage_mode,omitempty"`
	Encrypt     bool   `json:"encrypt,omitempty"`
}

func (c *Client) CreateSchedule(ctx context.Context, instanceID string, req CreateScheduleRequest) (*Schedule, error) {
	var out Schedule
	if err := c.do(ctx, "POST", "instances/"+instanceID+"/backup-schedule", req, &out); err != nil {
		return nil, err
	}
	return &out, nil
}

func (c *Client) ListAllSchedules(ctx context.Context) ([]Schedule, error) {
	var out ScheduleList
	if err := c.do(ctx, "GET", "schedules", nil, &out); err != nil {
		return nil, err
	}
	return out.Schedules, nil
}

type MintTokenRequest struct {
	Note string `json:"note,omitempty"`
}

type MintTokenResponse struct {
	Token     string    `json:"token"`
	ExpiresAt time.Time `json:"expires_at"`
}

func (c *Client) MintEnrollmentToken(ctx context.Context, req MintTokenRequest) (*MintTokenResponse, error) {
	var out MintTokenResponse
	if err := c.do(ctx, "POST", "enrollment-tokens", req, &out); err != nil {
		return nil, err
	}
	return &out, nil
}
