import { useEffect, useState } from 'react'
import { App as WailsApp, Backup, Instance } from '../wails'
import { formatBytes, formatRelative, stateTagClass, shortID } from '../lib/fmt'
import { PageHeader } from '../components/PageHeader'
import { ErrorBanner, EmptyState, Loading } from '../components/Misc'

export function BackupsView() {
  const [instances, setInstances] = useState<Instance[]>([])
  const [selectedInstance, setSelectedInstance] = useState<string>('')
  const [backups, setBackups] = useState<Backup[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | undefined>()

  useEffect(() => {
    (async () => {
      try {
        const is = await WailsApp.ListAllInstances()
        setInstances(is || [])
        if (is && is.length > 0 && !selectedInstance) {
          setSelectedInstance(is[0].instance_id)
        }
      } catch (e: any) {
        setError(String(e?.message ?? e))
      } finally {
        setLoading(false)
      }
    })()
  }, [])

  useEffect(() => {
    if (!selectedInstance) return
    refreshBackups()
    const t = setInterval(refreshBackups, 5000)
    return () => clearInterval(t)
  }, [selectedInstance])

  const refreshBackups = async () => {
    if (!selectedInstance) return
    try {
      const bs = await WailsApp.ListBackupsForInstance(selectedInstance)
      setBackups(bs || [])
    } catch (e: any) {
      setError(String(e?.message ?? e))
    }
  }

  const createBackup = async (encrypted: boolean) => {
    try {
      await WailsApp.CreateBackup(selectedInstance, {
        display_name: `manual ${new Date().toISOString().slice(0, 19)}`,
        encrypted,
      })
      refreshBackups()
    } catch (e: any) {
      setError(String(e?.message ?? e))
    }
  }

  const restore = async (backupID: string) => {
    const target = prompt(
      'Restore into which instance?\n(Paste a target instance UUID, or leave blank to restore in place.)',
      selectedInstance
    )
    if (target === null) return
    try {
      await WailsApp.RestoreBackup(backupID, target || selectedInstance)
      alert('Restore task dispatched. Follow progress in the instance logs.')
    } catch (e: any) {
      setError(String(e?.message ?? e))
    }
  }

  const deleteBackup = async (backupID: string) => {
    if (!confirm('Delete this backup?\nChunks with refcount 0 will be reclaimed on Central.')) return
    try {
      await WailsApp.DeleteBackup(backupID)
      refreshBackups()
    } catch (e: any) {
      setError(String(e?.message ?? e))
    }
  }

  const selectedInstanceName = instances.find(i => i.instance_id === selectedInstance)?.display_name

  return (
    <div>
      <PageHeader
        num="III"
        title="Backups"
        subtitle="Volume snapshots. Chunked, content-addressed, SHA-256 dedup, optionally AES-256-GCM encrypted."
      />

      <div className="mb-8 enter flex items-end gap-4">
        <div className="flex-1 max-w-xl">
          <div className="label mb-1.5">Instance</div>
          <select
            className="input-mono"
            value={selectedInstance}
            onChange={e => setSelectedInstance(e.target.value)}
          >
            {instances.length === 0 && <option value="">No instances available</option>}
            {instances.map(i => (
              <option key={i.instance_id} value={i.instance_id}>
                {i.display_name} — {shortID(i.instance_id)}
              </option>
            ))}
          </select>
        </div>
        <button className="btn-primary" disabled={!selectedInstance} onClick={() => createBackup(false)}>
          Snapshot →
        </button>
        <button className="btn-gold" disabled={!selectedInstance} onClick={() => createBackup(true)}>
          Snapshot (encrypted) →
        </button>
      </div>

      <ErrorBanner error={error} />

      {loading ? (
        <Loading />
      ) : !selectedInstance ? (
        <EmptyState>Select an instance to view its snapshots.</EmptyState>
      ) : backups.length === 0 ? (
        <EmptyState>
          No snapshots yet for <span className="text-bone">{selectedInstanceName}</span>.
        </EmptyState>
      ) : (
        <div className="border border-iron enter">
          <table className="data-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Status</th>
                <th>Size</th>
                <th>Chunks</th>
                <th>Storage</th>
                <th>Created</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {backups.map(b => (
                <tr key={b.backup_id}>
                  <td>
                    <div className="font-display text-bone">{b.display_name || 'unnamed'}</div>
                    <div className="font-mono text-[10px] text-pewter">{shortID(b.backup_id)}</div>
                  </td>
                  <td className="space-y-1">
                    <span className={stateTagClass(b.status)}>{b.status}</span>
                    {b.encrypted && <span className="tag-warn ml-1">encrypted</span>}
                  </td>
                  <td className="font-mono text-xs text-parchment">{formatBytes(b.total_bytes)}</td>
                  <td className="font-mono text-xs text-parchment">{b.chunk_count}</td>
                  <td className="font-mono text-xs text-pewter">{b.storage_mode}</td>
                  <td className="text-parchment italic font-display text-sm">
                    {formatRelative(b.created_at)}
                  </td>
                  <td className="text-right whitespace-nowrap">
                    {b.status === 'complete' && (
                      <button
                        className="btn-ghost text-xs mr-2"
                        onClick={() => restore(b.backup_id)}
                      >
                        Restore
                      </button>
                    )}
                    <button
                      className="btn-danger text-xs"
                      onClick={() => deleteBackup(b.backup_id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
