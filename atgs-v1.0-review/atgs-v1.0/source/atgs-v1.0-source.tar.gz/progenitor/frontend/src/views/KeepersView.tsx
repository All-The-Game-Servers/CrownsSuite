import { useEffect, useState } from 'react'
import { App as WailsApp, Keeper, MintTokenResponse } from '../wails'
import { formatDate, formatRelative, stateTagClass, shortID } from '../lib/fmt'
import { PageHeader } from '../components/PageHeader'
import { ErrorBanner, EmptyState, Loading } from '../components/Misc'

export function KeepersView() {
  const [keepers, setKeepers] = useState<Keeper[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | undefined>()
  const [minted, setMinted] = useState<MintTokenResponse | null>(null)
  const [minting, setMinting] = useState(false)

  const refresh = async () => {
    setError(undefined)
    try {
      const ks = await WailsApp.ListKeepers()
      setKeepers(ks || [])
    } catch (e: any) {
      setError(String(e?.message ?? e))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    refresh()
    const t = setInterval(refresh, 5000)
    return () => clearInterval(t)
  }, [])

  const mintToken = async () => {
    setMinting(true)
    try {
      const out = await WailsApp.MintEnrollmentToken(`progenitor ${new Date().toISOString()}`)
      setMinted(out)
    } catch (e: any) {
      setError(String(e?.message ?? e))
    } finally {
      setMinting(false)
    }
  }

  return (
    <div>
      <PageHeader
        num="I"
        title="Keepers"
        subtitle="Hosts enrolled to this Central. Each presents an mTLS certificate chained to the local CA."
        right={
          <button className="btn-gold" onClick={mintToken} disabled={minting}>
            {minting ? 'Minting…' : 'Mint enrollment token'}
          </button>
        }
      />

      {minted && (
        <div className="mb-8 border border-gold/40 bg-gold/5 px-6 py-5 enter">
          <div className="flex items-start justify-between mb-3">
            <div>
              <div className="label text-gold mb-1">Enrollment token — single use</div>
              <div className="section-sub">
                Expires {formatRelative(minted.expires_at)}.
              </div>
            </div>
            <button
              className="btn-ghost text-xs"
              onClick={() => setMinted(null)}
            >
              Dismiss
            </button>
          </div>
          <div className="font-mono text-sm text-bone break-all select-all bg-obsidian px-4 py-3 border border-iron">
            {minted.token}
          </div>
          <div className="mt-3 text-xs text-pewter font-display italic">
            Set <span className="font-mono text-parchment">ATGS_ENROLL_TOKEN</span> on
            the Keeper host and launch <span className="font-mono text-parchment">./keeper</span>.
          </div>
        </div>
      )}

      <ErrorBanner error={error} />

      {loading ? (
        <Loading />
      ) : keepers.length === 0 ? (
        <EmptyState>
          No Keepers enrolled. Mint a token above to add the first host.
        </EmptyState>
      ) : (
        <div className="border border-iron enter">
          <table className="data-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>State</th>
                <th>Agent</th>
                <th>Last Seen</th>
                <th>Certificate</th>
              </tr>
            </thead>
            <tbody>
              {keepers.map(k => (
                <tr key={k.id}>
                  <td className="font-mono text-xs text-bone" title={k.id}>
                    {shortID(k.id)}
                  </td>
                  <td>
                    <span className={stateTagClass(k.state)}>{k.state}</span>
                  </td>
                  <td className="font-mono text-xs text-parchment">{k.version || '—'}</td>
                  <td className="text-parchment italic font-display">
                    {formatRelative(k.last_seen_at)}
                  </td>
                  <td className="font-mono text-xs text-pewter">
                    exp {formatDate(k.cert_not_after)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
