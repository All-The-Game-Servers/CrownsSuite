import { useEffect, useState } from 'react'
import { App as WailsApp, Instance, Schedule } from '../wails'
import { formatRelative, shortID } from '../lib/fmt'
import { PageHeader } from '../components/PageHeader'
import { ErrorBanner, EmptyState, Loading } from '../components/Misc'

// SchedulesView — list all backup schedules, create new ones.
// Cron display is left as-is (we don't humanize "* * * * *" to "every minute"
// because the operators reading this are shell people; literal cron is the
// canonical representation).

export function SchedulesView() {
  const [schedules, setSchedules] = useState<Schedule[]>([])
  const [instances, setInstances] = useState<Instance[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | undefined>()
  const [showCreate, setShowCreate] = useState(false)

  const refresh = async () => {
    setError(undefined)
    try {
      const [scheds, is] = await Promise.all([
        WailsApp.ListAllSchedules(),
        WailsApp.ListAllInstances(),
      ])
      setSchedules(scheds || [])
      setInstances(is || [])
    } catch (e: any) {
      setError(String(e?.message ?? e))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    refresh()
    const t = setInterval(refresh, 10000)
    return () => clearInterval(t)
  }, [])

  const instanceName = (id: string) =>
    instances.find(i => i.instance_id === id)?.display_name || shortID(id)

  return (
    <div>
      <PageHeader
        num="IV"
        title="Schedules"
        subtitle="Cron-driven snapshots. The scheduler polls every 30 seconds; retention prunes older backups automatically."
        right={
          <button
            className="btn-gold"
            disabled={instances.length === 0}
            onClick={() => setShowCreate(s => !s)}
          >
            {showCreate ? 'Close' : 'New schedule'}
          </button>
        }
      />

      <ErrorBanner error={error} />

      {showCreate && (
        <CreateSchedulePanel
          instances={instances}
          onClose={() => setShowCreate(false)}
          onCreated={() => { setShowCreate(false); refresh() }}
        />
      )}

      {loading ? (
        <Loading />
      ) : schedules.length === 0 ? (
        <EmptyState>No schedules defined. Point one at an instance above.</EmptyState>
      ) : (
        <div className="border border-iron enter">
          <table className="data-table">
            <thead>
              <tr>
                <th>Instance</th>
                <th>Cron</th>
                <th>Retention</th>
                <th>Encrypt</th>
                <th>Next run</th>
                <th>Last run</th>
                <th>State</th>
              </tr>
            </thead>
            <tbody>
              {schedules.map(s => (
                <tr key={s.schedule_id}>
                  <td>
                    <div className="font-display text-bone">{instanceName(s.instance_id)}</div>
                    <div className="font-mono text-[10px] text-pewter">{shortID(s.instance_id)}</div>
                  </td>
                  <td className="font-mono text-xs text-gold">{s.cron_expr}</td>
                  <td className="font-mono text-xs text-parchment">
                    {s.retention > 0 ? `keep ${s.retention}` : 'keep all'}
                  </td>
                  <td className="text-xs text-parchment">
                    {s.encrypt ? <span className="tag-warn">yes</span> : <span className="tag-mute">no</span>}
                  </td>
                  <td className="text-parchment italic font-display text-sm">
                    {formatRelative(s.next_run_at)}
                  </td>
                  <td className="text-parchment italic font-display text-sm">
                    {s.last_run_at ? formatRelative(s.last_run_at) : '—'}
                  </td>
                  <td>
                    {s.enabled
                      ? <span className="tag-ok">enabled</span>
                      : <span className="tag-mute">disabled</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Cron cheatsheet - small footnote-style reference since
          operators will want to remember the format. */}
      <div className="mt-10 enter">
        <div className="label mb-3">Cron reference</div>
        <div className="grid grid-cols-5 gap-px bg-iron border border-iron font-mono text-xs">
          <CronCell label="minute" range="0–59" />
          <CronCell label="hour" range="0–23" />
          <CronCell label="day of month" range="1–31" />
          <CronCell label="month" range="1–12" />
          <CronCell label="day of week" range="0–6" />
        </div>
        <div className="mt-3 text-xs text-pewter font-display italic">
          Shortcuts: <span className="font-mono text-parchment not-italic">@hourly</span>
          , <span className="font-mono text-parchment not-italic">@daily</span>
          , <span className="font-mono text-parchment not-italic">@weekly</span>
          , <span className="font-mono text-parchment not-italic">@monthly</span>.
        </div>
      </div>
    </div>
  )
}

function CronCell({ label, range }: { label: string; range: string }) {
  return (
    <div className="bg-obsidian px-3 py-3">
      <div className="label mb-1">{label}</div>
      <div className="text-parchment">{range}</div>
    </div>
  )
}

function CreateSchedulePanel({
  instances,
  onClose,
  onCreated,
}: {
  instances: Instance[]
  onClose: () => void
  onCreated: () => void
}) {
  const [instanceID, setInstanceID] = useState(instances[0]?.instance_id ?? '')
  const [cronExpr, setCronExpr] = useState('0 3 * * *')
  const [retention, setRetention] = useState(7)
  const [encrypt, setEncrypt] = useState(false)
  const [error, setError] = useState<string | undefined>()
  const [busy, setBusy] = useState(false)

  const submit = async () => {
    setError(undefined)
    setBusy(true)
    try {
      await WailsApp.CreateSchedule(instanceID, {
        cron_expr: cronExpr,
        retention,
        encrypt,
      })
      onCreated()
    } catch (e: any) {
      setError(String(e?.message ?? e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="border border-iron mb-8 enter">
      <div className="px-6 py-4 border-b border-iron flex items-center justify-between bg-carbon">
        <div>
          <div className="section-number mb-1">§ — scheduling</div>
          <div className="font-display text-2xl text-bone">New schedule</div>
        </div>
        <button className="btn-ghost text-xs" onClick={onClose}>Cancel</button>
      </div>
      <div className="px-6 py-6 grid grid-cols-2 gap-x-8 gap-y-5 bg-obsidian">
        <div className="col-span-2">
          <div className="label mb-1.5">Instance</div>
          <select
            className="input-mono"
            value={instanceID}
            onChange={e => setInstanceID(e.target.value)}
          >
            {instances.map(i => (
              <option key={i.instance_id} value={i.instance_id}>
                {i.display_name} — {shortID(i.instance_id)}
              </option>
            ))}
          </select>
        </div>
        <div>
          <div className="label mb-1.5">Cron expression</div>
          <input
            className="input-mono"
            value={cronExpr}
            onChange={e => setCronExpr(e.target.value)}
            placeholder="0 3 * * *"
          />
          <div className="mt-1 text-xs text-pewter font-display italic">
            Five-field or <span className="font-mono text-parchment not-italic">@daily</span> style.
          </div>
        </div>
        <div>
          <div className="label mb-1.5">Retention (backups kept)</div>
          <input
            className="input-mono"
            type="number"
            min={0}
            value={retention}
            onChange={e => setRetention(Number(e.target.value))}
          />
          <div className="mt-1 text-xs text-pewter font-display italic">
            0 keeps all. Others prune oldest beyond this count.
          </div>
        </div>
        <label className="col-span-2 flex items-start gap-3 cursor-pointer select-none group">
          <span
            className={
              'mt-0.5 w-4 h-4 border flex items-center justify-center flex-shrink-0 transition-colors ' +
              (encrypt ? 'bg-gold border-gold' : 'border-pewter group-hover:border-bone')
            }
          >
            {encrypt && <span className="text-obsidian text-xs font-bold">✓</span>}
          </span>
          <input type="checkbox" className="sr-only" checked={encrypt} onChange={e => setEncrypt(e.target.checked)} />
          <div>
            <div className="text-bone">Encrypt with Central master key</div>
            <div className="text-xs text-pewter mt-1 font-display italic">
              Requires <span className="font-mono text-parchment not-italic">ATGS_CENTRAL_BACKUP_MASTER_KEY</span> set on Central.
            </div>
          </div>
        </label>

        {error && (
          <div className="col-span-2 border-l-2 border-rust bg-rust/5 px-4 py-2 font-mono text-xs text-rust">
            {error}
          </div>
        )}

        <div className="col-span-2 pt-2 flex justify-end">
          <button
            className="btn-gold"
            disabled={busy || !instanceID || !cronExpr}
            onClick={submit}
          >
            {busy ? 'Creating…' : 'Create schedule →'}
          </button>
        </div>
      </div>
    </div>
  )
}
