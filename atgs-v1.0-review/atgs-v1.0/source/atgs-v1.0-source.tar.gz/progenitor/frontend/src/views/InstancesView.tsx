import { useEffect, useState } from 'react'
import { App as WailsApp, Instance, Keeper } from '../wails'
import { formatBytes, formatRelative, stateTagClass, shortID } from '../lib/fmt'
import { PageHeader } from '../components/PageHeader'
import { ErrorBanner, EmptyState, Loading } from '../components/Misc'

export function InstancesView() {
  const [instances, setInstances] = useState<Instance[]>([])
  const [keepers, setKeepers] = useState<Keeper[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | undefined>()
  const [showCreate, setShowCreate] = useState(false)

  const refresh = async () => {
    setError(undefined)
    try {
      const [is, ks] = await Promise.all([
        WailsApp.ListAllInstances(),
        WailsApp.ListKeepers(),
      ])
      setInstances(is || [])
      setKeepers(ks || [])
    } catch (e: any) {
      setError(String(e?.message ?? e))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    refresh()
    const t = setInterval(refresh, 5000)
    return () => clearInterval(t)
  }, [])

  const action = async (fn: () => Promise<any>) => {
    try {
      await fn()
      await refresh()
    } catch (e: any) {
      setError(String(e?.message ?? e))
    }
  }

  const keeperLabel = (id: string) => {
    const k = keepers.find(x => x.id === id)
    return k ? shortID(k.id) : shortID(id)
  }

  return (
    <div>
      <PageHeader
        num="II"
        title="Instances"
        subtitle="Game servers across all Keepers. Lifecycle state flows Central → Keeper → Docker."
        right={
          <button
            className="btn-gold"
            disabled={keepers.length === 0}
            onClick={() => setShowCreate(s => !s)}
          >
            {showCreate ? 'Close' : 'New instance'}
          </button>
        }
      />

      <ErrorBanner error={error} />

      {showCreate && (
        <CreateInstancePanel
          keepers={keepers}
          onClose={() => setShowCreate(false)}
          onCreated={() => { setShowCreate(false); refresh() }}
        />
      )}

      {loading ? (
        <Loading />
      ) : instances.length === 0 ? (
        <EmptyState>No instances dispatched.</EmptyState>
      ) : (
        <div className="border border-iron enter">
          <table className="data-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Egg</th>
                <th>Keeper</th>
                <th>State</th>
                <th>Resources</th>
                <th>Created</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {instances.map(i => (
                <tr key={i.instance_id}>
                  <td>
                    <div className="font-display text-lg text-bone">{i.display_name}</div>
                    <div className="font-mono text-[10px] text-pewter">{shortID(i.instance_id)}</div>
                  </td>
                  <td className="font-mono text-xs text-parchment">{i.egg_id}</td>
                  <td className="font-mono text-xs text-pewter" title={i.keeper_id}>
                    {keeperLabel(i.keeper_id)}
                  </td>
                  <td>
                    <span className={stateTagClass(i.state)}>{i.state}</span>
                  </td>
                  <td className="font-mono text-xs text-parchment">
                    {formatBytes(i.memory_bytes)} <span className="text-pewter">/</span> {i.cpu_shares} cpu
                  </td>
                  <td className="text-parchment italic font-display text-sm">
                    {formatRelative(i.created_at)}
                  </td>
                  <td className="text-right whitespace-nowrap">
                    {i.state !== 'running' && (
                      <button
                        className="btn-ghost text-xs mr-2"
                        onClick={() => action(() => WailsApp.StartInstance(i.instance_id))}
                      >
                        Start
                      </button>
                    )}
                    {i.state === 'running' && (
                      <button
                        className="btn-ghost text-xs mr-2"
                        onClick={() => action(() => WailsApp.StopInstance(i.instance_id))}
                      >
                        Stop
                      </button>
                    )}
                    <button
                      className="btn-danger text-xs"
                      onClick={() => {
                        if (confirm(`Delete ${i.display_name}? This is permanent.`)) {
                          action(() => WailsApp.DeleteInstance(i.instance_id))
                        }
                      }}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

function CreateInstancePanel({
  keepers,
  onClose,
  onCreated,
}: {
  keepers: Keeper[]
  onClose: () => void
  onCreated: () => void
}) {
  const [keeperID, setKeeperID] = useState(keepers[0]?.id ?? '')
  const [displayName, setDisplayName] = useState('')
  const [eggID, setEggID] = useState('minecraft-java-paper')
  const [hostname, setHostname] = useState('')
  const [memoryGB, setMemoryGB] = useState(2)
  const [cpuShares, setCpuShares] = useState(1024)
  const [error, setError] = useState<string | undefined>()
  const [busy, setBusy] = useState(false)

  const submit = async () => {
    setError(undefined)
    setBusy(true)
    try {
      await WailsApp.CreateInstance(keeperID, {
        egg_id: eggID,
        display_name: displayName,
        hostname: hostname || undefined,
        memory_bytes: memoryGB * 1024 * 1024 * 1024,
        cpu_shares: cpuShares,
      })
      onCreated()
    } catch (e: any) {
      setError(String(e?.message ?? e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="border border-iron mb-8 enter">
      <div className="px-6 py-4 border-b border-iron flex items-center justify-between bg-carbon">
        <div>
          <div className="section-number mb-1">§ — dispatch</div>
          <div className="font-display text-2xl text-bone">New instance</div>
        </div>
        <button className="btn-ghost text-xs" onClick={onClose}>Cancel</button>
      </div>
      <div className="px-6 py-6 grid grid-cols-2 gap-x-8 gap-y-5 bg-obsidian">
        <Field label="Display name">
          <input className="input" value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="Lowlight SMP" />
        </Field>
        <Field label="Keeper">
          <select className="input-mono" value={keeperID} onChange={e => setKeeperID(e.target.value)}>
            {keepers.map(k => (
              <option key={k.id} value={k.id}>{shortID(k.id)} — {k.state}</option>
            ))}
          </select>
        </Field>
        <Field label="Egg">
          <input className="input-mono" value={eggID} onChange={e => setEggID(e.target.value)} />
        </Field>
        <Field label="Hostname (optional)">
          <input className="input-mono" value={hostname} onChange={e => setHostname(e.target.value)} placeholder="server.example.com" />
        </Field>
        <Field label="Memory (GiB)">
          <input className="input-mono" type="number" min={1} value={memoryGB} onChange={e => setMemoryGB(Number(e.target.value))} />
        </Field>
        <Field label="CPU shares">
          <input className="input-mono" type="number" min={128} value={cpuShares} onChange={e => setCpuShares(Number(e.target.value))} />
        </Field>

        {error && (
          <div className="col-span-2 border-l-2 border-rust bg-rust/5 px-4 py-2 font-mono text-xs text-rust">
            {error}
          </div>
        )}

        <div className="col-span-2 pt-2 flex justify-end">
          <button
            className="btn-gold"
            disabled={busy || !displayName || !keeperID || !eggID}
            onClick={submit}
          >
            {busy ? 'Dispatching…' : 'Dispatch →'}
          </button>
        </div>
      </div>
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="label mb-1.5">{label}</div>
      {children}
    </div>
  )
}
