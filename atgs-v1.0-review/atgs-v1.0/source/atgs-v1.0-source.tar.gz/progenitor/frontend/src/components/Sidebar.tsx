import { useEffect, useState } from 'react'
import { App as WailsApp, WhoamiResponse } from '../wails'
import { ViewKey } from '../App'

interface Props {
  active: ViewKey
  onChange: (v: ViewKey) => void
  onDisconnect: () => void | Promise<void>
}

// Numbered nav items - gives the app a document/dossier feel
const nav: { key: ViewKey; label: string; num: string }[] = [
  { key: 'keepers',   label: 'Keepers',   num: 'I' },
  { key: 'instances', label: 'Instances', num: 'II' },
  { key: 'backups',   label: 'Backups',   num: 'III' },
  { key: 'schedules', label: 'Schedules', num: 'IV' },
]

export function Sidebar({ active, onChange, onDisconnect }: Props) {
  const [whoami, setWhoami] = useState<WhoamiResponse | null>(null)

  useEffect(() => {
    WailsApp.Whoami().then(setWhoami).catch(() => setWhoami(null))
  }, [])

  return (
    <aside className="w-64 shrink-0 bg-carbon border-r border-iron flex flex-col">
      {/* Masthead */}
      <header className="px-6 pt-7 pb-6 border-b border-iron">
        <div className="font-display text-5xl text-gold leading-none tracking-tight">
          ATGS
        </div>
        <div className="mt-2 font-display italic text-parchment text-sm">
          Progenitor Console
        </div>
        <div className="mt-1 label">v 0.5 — phase V</div>
      </header>

      {/* Nav */}
      <nav className="flex-1 py-4">
        <div className="label px-6 mb-2">Sections</div>
        {nav.map((item, i) => {
          const isActive = active === item.key
          return (
            <button
              key={item.key}
              onClick={() => onChange(item.key)}
              className={
                'w-full text-left px-6 py-3 flex items-baseline gap-3 transition-colors enter ' +
                (isActive
                  ? 'bg-obsidian text-bone'
                  : 'text-parchment hover:text-bone hover:bg-obsidian/50')
              }
              style={{ animationDelay: `${60 * i}ms` }}
            >
              <span
                className={
                  'font-mono text-xs w-6 ' +
                  (isActive ? 'text-gold' : 'text-pewter')
                }
              >
                {item.num}.
              </span>
              <span
                className={
                  'font-display text-xl ' +
                  (isActive ? 'text-bone' : '')
                }
              >
                {item.label}
              </span>
              {isActive && (
                <span className="ml-auto w-1 h-5 bg-gold self-center" />
              )}
            </button>
          )
        })}
      </nav>

      {/* Identity footer */}
      <footer className="border-t border-iron px-6 py-5 text-xs">
        {whoami ? (
          <>
            <div className="label mb-2">Operator</div>
            <div className="font-mono text-parchment truncate" title={whoami.progenitor_id}>
              {whoami.progenitor_id}
            </div>
            <div className="mt-3 label mb-1">Central</div>
            <div className="font-mono text-parchment">{whoami.server_version}</div>
          </>
        ) : (
          <div className="label">Identifying…</div>
        )}
        <button className="btn-ghost w-full mt-4 justify-center text-xs" onClick={onDisconnect}>
          Disconnect
        </button>
      </footer>
    </aside>
  )
}
