// Package routing is the relay's local routing-table cache.
//
// The relay maintains a SQLite-backed mirror of Central's routing table so
// a fresh start doesn't immediately trigger a full snapshot pull. Lookup is
// O(1) via the in-memory map; the SQLite table is the durable backing.
//
// Writes go through Apply (for deltas) or Replace (for snapshots). Both
// update the in-memory map AND persist to SQLite in the same call so a
// crash between the two can't leave the cache inconsistent.
package routing

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"path/filepath"
	"sync"
	"time"

	_ "modernc.org/sqlite"
)

const schema = `
CREATE TABLE IF NOT EXISTS routing_entries (
    hostname    TEXT PRIMARY KEY,
    instance_id TEXT NOT NULL,
    keeper_id   TEXT NOT NULL,
    host_port   INTEGER NOT NULL,
    version     INTEGER NOT NULL,
    updated_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS cache_meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
`

const metaKeyKnownVersion = "known_version"

// Entry is one routing record as the relay sees it.
type Entry struct {
	Hostname   string
	InstanceID string
	KeeperID   string
	HostPort   int
	Version    int64
}

// Cache is a concurrent-safe routing table, persisted to SQLite.
type Cache struct {
	db *sql.DB

	mu      sync.RWMutex
	byHost  map[string]Entry
	version int64
}

// Open creates or reopens the cache at <stateDir>/routing.db.
func Open(stateDir string) (*Cache, error) {
	path := filepath.Join(stateDir, "routing.db")
	db, err := sql.Open("sqlite", path+"?_pragma=journal_mode(WAL)&_pragma=busy_timeout(5000)")
	if err != nil {
		return nil, fmt.Errorf("open: %w", err)
	}
	if err := db.Ping(); err != nil {
		db.Close()
		return nil, fmt.Errorf("ping: %w", err)
	}
	if _, err := db.Exec(schema); err != nil {
		db.Close()
		return nil, fmt.Errorf("schema: %w", err)
	}
	c := &Cache{
		db:     db,
		byHost: make(map[string]Entry),
	}
	if err := c.loadFromDB(); err != nil {
		db.Close()
		return nil, fmt.Errorf("load cache: %w", err)
	}
	return c, nil
}

func (c *Cache) Close() error { return c.db.Close() }

// loadFromDB populates the in-memory map from SQLite at startup.
func (c *Cache) loadFromDB() error {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	rows, err := c.db.QueryContext(ctx, `
		SELECT hostname, instance_id, keeper_id, host_port, version
		FROM routing_entries
	`)
	if err != nil {
		return err
	}
	defer rows.Close()

	for rows.Next() {
		var e Entry
		if err := rows.Scan(&e.Hostname, &e.InstanceID, &e.KeeperID, &e.HostPort, &e.Version); err != nil {
			return err
		}
		c.byHost[e.Hostname] = e
	}
	if err := rows.Err(); err != nil {
		return err
	}

	// Load known_version.
	var raw string
	err = c.db.QueryRowContext(ctx, `SELECT value FROM cache_meta WHERE key = ?`, metaKeyKnownVersion).Scan(&raw)
	if errors.Is(err, sql.ErrNoRows) {
		c.version = 0
		return nil
	}
	if err != nil {
		return err
	}
	fmt.Sscanf(raw, "%d", &c.version)
	return nil
}

// KnownVersion returns the highest version the cache has applied. Used by
// the sync client to decide whether to request snapshot or delta on connect.
func (c *Cache) KnownVersion() int64 {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.version
}

// Lookup returns the entry for a hostname, or (_, false) if absent.
// Case-insensitive; lookup normalizes to lowercase.
func (c *Cache) Lookup(hostname string) (Entry, bool) {
	c.mu.RLock()
	defer c.mu.RUnlock()
	e, ok := c.byHost[NormalizeHostname(hostname)]
	return e, ok
}

// Size returns the number of entries in the cache. Useful for observability.
func (c *Cache) Size() int {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return len(c.byHost)
}

// Replace atomically swaps the cache contents with the given snapshot and
// records the new known_version.
func (c *Cache) Replace(ctx context.Context, entries []Entry, newVersion int64) error {
	tx, err := c.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()

	if _, err := tx.ExecContext(ctx, `DELETE FROM routing_entries`); err != nil {
		return err
	}
	stmt, err := tx.PrepareContext(ctx, `
		INSERT INTO routing_entries (hostname, instance_id, keeper_id, host_port, version, updated_at)
		VALUES (?, ?, ?, ?, ?, ?)
	`)
	if err != nil {
		return err
	}
	now := time.Now().Unix()
	for _, e := range entries {
		if _, err := stmt.ExecContext(ctx, normalize(e.Hostname), e.InstanceID, e.KeeperID, e.HostPort, e.Version, now); err != nil {
			stmt.Close()
			return err
		}
	}
	stmt.Close()

	if _, err := tx.ExecContext(ctx,
		`INSERT INTO cache_meta (key, value) VALUES (?, ?)
		 ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
		metaKeyKnownVersion, fmt.Sprintf("%d", newVersion)); err != nil {
		return err
	}
	if err := tx.Commit(); err != nil {
		return err
	}

	// Swap the in-memory map under the write lock.
	c.mu.Lock()
	c.byHost = make(map[string]Entry, len(entries))
	for _, e := range entries {
		e.Hostname = normalize(e.Hostname)
		c.byHost[e.Hostname] = e
	}
	c.version = newVersion
	c.mu.Unlock()
	return nil
}

// Apply applies a single routing delta.
func (c *Cache) Apply(ctx context.Context, eventType string, e Entry) error {
		host := NormalizeHostname(e.Hostname)
	tx, err := c.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()

	now := time.Now().Unix()
	switch eventType {
	case "upsert":
		if _, err := tx.ExecContext(ctx, `
			INSERT INTO routing_entries (hostname, instance_id, keeper_id, host_port, version, updated_at)
			VALUES (?, ?, ?, ?, ?, ?)
			ON CONFLICT(hostname) DO UPDATE SET
				instance_id = excluded.instance_id,
				keeper_id   = excluded.keeper_id,
				host_port   = excluded.host_port,
				version     = excluded.version,
				updated_at  = excluded.updated_at
		`, host, e.InstanceID, e.KeeperID, e.HostPort, e.Version, now); err != nil {
			return err
		}
	case "delete":
		if _, err := tx.ExecContext(ctx, `DELETE FROM routing_entries WHERE hostname = ?`, host); err != nil {
			return err
		}
	default:
		return fmt.Errorf("unknown event type: %s", eventType)
	}

	if _, err := tx.ExecContext(ctx,
		`INSERT INTO cache_meta (key, value) VALUES (?, ?)
		 ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
		metaKeyKnownVersion, fmt.Sprintf("%d", e.Version)); err != nil {
		return err
	}
	if err := tx.Commit(); err != nil {
		return err
	}

	c.mu.Lock()
	switch eventType {
	case "upsert":
		e.Hostname = host
		c.byHost[host] = e
	case "delete":
		delete(c.byHost, host)
	}
	if e.Version > c.version {
		c.version = e.Version
	}
	c.mu.Unlock()
	return nil
}

func NormalizeHostname(hostname string) string {
	// Lowercase without pulling in strings.ToLower for one call site.
	b := []byte(hostname)
	for i, c := range b {
		if c >= 'A' && c <= 'Z' {
			b[i] = c + ('a' - 'A')
		}
	}
	return string(b)
}

func normalize(hostname string) string {
	return NormalizeHostname(hostname)
}
