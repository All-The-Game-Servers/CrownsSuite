package store

import (
	"context"
	"errors"
	"time"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
)

// RoutingEntry is one row of the authoritative routing table: a hostname and
// where to send traffic for it. Delivered to relays via snapshot or delta.
type RoutingEntry struct {
	Hostname   string
	InstanceID uuid.UUID
	KeeperID   uuid.UUID
	HostPort   int
	Version    int64 // the routing_events.version when this entry was last set
}

// RoutingEvent is the delta form. Event types: "upsert" or "delete".
// On a delete, InstanceID/KeeperID/HostPort are zero and should be ignored.
type RoutingEvent struct {
	Version    int64
	At         time.Time
	EventType  string
	Hostname   string
	InstanceID uuid.UUID
	KeeperID   uuid.UUID
	HostPort   int
}

// RoutingSnapshot returns the full current routing table plus the maximum
// version that contributed to it. Relays call this on first connect (or when
// their cache is empty).
//
// Implementation: for each hostname that currently resolves to something,
// take the most recent upsert event. Hostnames whose most recent event is a
// delete are excluded.
//
// Returns (entries, currentVersion, error). currentVersion is the max
// version in the log; relays should remember this to resume.
func (s *Store) RoutingSnapshot(ctx context.Context) ([]RoutingEntry, int64, error) {
	// Current version: max of routing_events. Zero if empty.
	var currentVersion int64
	if err := s.pool.QueryRow(ctx, `
		SELECT COALESCE(MAX(version), 0) FROM routing_events
	`).Scan(&currentVersion); err != nil {
		return nil, 0, err
	}

	// Most recent event per hostname, keeping only those whose latest event
	// is an upsert. DISTINCT ON (hostname) ... ORDER BY hostname, version DESC
	// picks the newest row per hostname in a single pass.
	rows, err := s.pool.Query(ctx, `
		SELECT DISTINCT ON (hostname)
		       hostname, event_type, instance_id, keeper_id, host_port, version
		FROM routing_events
		ORDER BY hostname, version DESC
	`)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	var out []RoutingEntry
	for rows.Next() {
		var (
			e           RoutingEntry
			eventType   string
			instanceID  *uuid.UUID
			keeperID    *uuid.UUID
			hostPort    *int
		)
		if err := rows.Scan(&e.Hostname, &eventType, &instanceID, &keeperID, &hostPort, &e.Version); err != nil {
			return nil, 0, err
		}
		if eventType != "upsert" {
			continue
		}
		if instanceID != nil {
			e.InstanceID = *instanceID
		}
		if keeperID != nil {
			e.KeeperID = *keeperID
		}
		if hostPort != nil {
			e.HostPort = *hostPort
		}
		out = append(out, e)
	}
	return out, currentVersion, rows.Err()
}

// RoutingEventsSince returns all events with version > sinceVersion, in
// ascending version order. Used by relays to catch up from a known point.
// Caller should enforce a page size; this returns everything.
func (s *Store) RoutingEventsSince(ctx context.Context, sinceVersion int64) ([]RoutingEvent, error) {
	rows, err := s.pool.Query(ctx, `
		SELECT version, at, event_type, hostname, instance_id, keeper_id, host_port
		FROM routing_events
		WHERE version > $1
		ORDER BY version ASC
	`, sinceVersion)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []RoutingEvent
	for rows.Next() {
		var (
			e          RoutingEvent
			instanceID *uuid.UUID
			keeperID   *uuid.UUID
			hostPort   *int
		)
		if err := rows.Scan(&e.Version, &e.At, &e.EventType, &e.Hostname, &instanceID, &keeperID, &hostPort); err != nil {
			return nil, err
		}
		if instanceID != nil {
			e.InstanceID = *instanceID
		}
		if keeperID != nil {
			e.KeeperID = *keeperID
		}
		if hostPort != nil {
			e.HostPort = *hostPort
		}
		out = append(out, e)
	}
	return out, rows.Err()
}

// AppendRoutingUpsert records a hostname-to-instance routing assignment.
// Used when an instance is created with a hostname or has its hostname
// changed.
//
// Returns the new version number so the caller can publish a delta to
// live relay connections without waiting for a poll.
func (s *Store) AppendRoutingUpsert(ctx context.Context, hostname string, instanceID, keeperID uuid.UUID, hostPort int) (int64, error) {
	var v int64
	err := s.pool.QueryRow(ctx, `
		INSERT INTO routing_events (event_type, hostname, instance_id, keeper_id, host_port)
		VALUES ('upsert', $1, $2, $3, $4)
		RETURNING version
	`, hostname, instanceID, keeperID, hostPort).Scan(&v)
	return v, err
}

// AppendRoutingDelete records that a hostname should no longer route.
// Used when an instance is deleted.
func (s *Store) AppendRoutingDelete(ctx context.Context, hostname string) (int64, error) {
	var v int64
	err := s.pool.QueryRow(ctx, `
		INSERT INTO routing_events (event_type, hostname)
		VALUES ('delete', $1)
		RETURNING version
	`, hostname).Scan(&v)
	return v, err
}

// SetInstanceHostname assigns (or clears) the hostname on an instance row.
// Uniqueness is enforced by the partial index on instances.hostname.
func (s *Store) SetInstanceHostname(ctx context.Context, instanceID uuid.UUID, hostname string) error {
	var h *string
	if hostname != "" {
		h = &hostname
	}
	_, err := s.pool.Exec(ctx, `
		UPDATE instances SET hostname = $2, updated_at = NOW() WHERE instance_id = $1
	`, instanceID, h)
	return err
}

// SetInstanceHostPort stores the host port Docker assigned on the Keeper.
// Separate from SetInstanceContainerID because the Keeper knows the container
// ID at create time but the port only after inspect.
func (s *Store) SetInstanceHostPort(ctx context.Context, instanceID uuid.UUID, hostPort int) error {
	_, err := s.pool.Exec(ctx, `
		UPDATE instances SET host_port = $2, updated_at = NOW() WHERE instance_id = $1
	`, instanceID, hostPort)
	return err
}

// GetInstanceHostname returns the hostname assigned to an instance, or "" if
// none. Used during delete so we know what routing entry to retire.
func (s *Store) GetInstanceHostname(ctx context.Context, instanceID uuid.UUID) (string, error) {
	var h *string
	err := s.pool.QueryRow(ctx, `
		SELECT hostname FROM instances WHERE instance_id = $1
	`, instanceID).Scan(&h)
	if errors.Is(err, pgx.ErrNoRows) {
		return "", ErrNotFound
	}
	if err != nil {
		return "", err
	}
	if h == nil {
		return "", nil
	}
	return *h, nil
}
