# ATGS Roadmap

This document tracks the phase plan. Each phase is a meaningful slice, not a
checklist of everything that will eventually exist.

## Phase 0 — Foundations (DONE in initial commit)

- Monorepo layout (`central/`, `keeper/`, `shared/`, `migrations/`, `deploy/`)
- Go workspace
- Postgres schema for keepers, enrollment tokens, sessions, audit log
- Shared protocol package (Envelope, hellos, ping/pong, resources, errors)
- Shared PKI helpers (CA creation, CSR sign)

## Phase 1 — Enrollment + Control Channel (THIS RELEASE)

A Keeper enrolls with Central using a one-time token, receives an mTLS
identity, and holds a persistent WebSocket open.

- Central: `serve`, `migrate`, `bootstrap-ca`, `mint-enrollment-token`
- Central: `/api/v1/version`, `/api/v1/enrollment-tokens`, `/api/v1/keepers`,
  `/api/v1/keepers/{id}/revoke`, `/api/v1/enroll`, `/ws`
- Keeper: first-run enrollment, persistent mTLS WebSocket, ping/pong,
  resources report placeholder, exponential backoff reconnect
- Audit log captures enrollment and session lifecycle
- Supersede-on-reconnect so a stale ghost connection can't block a real one

Not yet: task model, Docker, relay, backups, console.

## Phase 2 — Task Model + Docker Runtime

Typed tasks flow Central → Keeper over the control channel. Keeper runs
Docker containers on instruction and streams logs back.

- `protocol` package: task envelopes, ack/progress/result
- Central: task queue + dispatcher, task status API
- Keeper: Docker SDK integration, egg system port, log streaming
- Minimum task set: `instance.create`, `instance.start`, `instance.stop`,
  `instance.delete`, `instance.logs.tail`, `keeper.resources.snapshot`
- Real resource sampling (gopsutil)

Demo: spin up a Minecraft Java server on a Keeper from curl against Central.

## Phase 3 — Ingress + Relay

Public player traffic reaches the Minecraft server on the Keeper without
port forwarding.

- Central accepts inbound TCP on 25565 (or per-server allocated ports)
- Parse Minecraft handshake to find server address, route accordingly
- Dedicated binary subprotocol for relay streams over the control channel
- Horizontally scalable relay nodes separate from the control-plane node
- Benchmarks: target at least 50 concurrent players per Keeper at <100ms
  added latency on a local relay

This phase deserves its own design doc before implementation.

## Phase 4 — Backups

- Snapshot instance data dirs on schedule or on demand
- Chunked upload over the control channel
- Central stores metadata; bytes go to object storage (S3-compatible)
- Restore path that can recreate an instance on any Keeper

## Phase 5 — Progenitor Console

- Desktop app (Tauri recommended, Electron acceptable)
- Wraps the same Central API the CLI and web UI use
- First-class features: keeper list, task dispatch, log streaming, audit view

## Phase 6 — Keeper UX

- Local-facing UI showing resources, running instances, pause switch
- Cross-platform (Windows + Linux tray apps)

## Phase 7 — Hardening

- Progenitor auth (OIDC or local accounts with bcrypt + TOTP)
- Rate limits on every HTTP route
- Signed task envelopes with replay protection (nonce + timestamp)
- Independent resource cap enforcement on both Central and Keeper
- Cert rotation flow for Keepers (90-day lifetime currently)
- Audit log review tools

## Phase 8 — Scale + Platform Breadth

- Multi-node relay with sticky session by server hostname
- Bedrock support (UDP relay, different beast)
- Billing
- Marketplace for pre-built server templates
